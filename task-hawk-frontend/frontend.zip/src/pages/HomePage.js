import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { Box, Typography } from '@mui/material';
import './HomePage.css'; // Create this CSS file

const HomePage = () => {
  const navigate = useNavigate();

  return (
    <Box className="homepage-container">
      <Container>
        <Row className="justify-content-center text-center">
          <Col md={8}>
            <Typography variant="h2" className="homepage-title">
              Welcome to Task Hawk!
            </Typography>
            <Typography variant="h5" className="homepage-subtitle">
              Your AI-powered smart task scheduler.
            </Typography>
            <Typography variant="body1" className="homepage-description">
              Organize your life, boost productivity, and achieve your goals with ease.
            </Typography>
            <Box sx={{ mt: 4 }}>
              <Button 
                variant="primary" 
                size="lg" 
                onClick={() => navigate('/login')} 
                className="me-3 homepage-btn"
              >
                Login
              </Button>
              <Button 
                variant="outline-primary" 
                size="lg" 
                onClick={() => navigate('/signup')} 
                className="homepage-btn"
              >
                Sign Up
              </Button>
            </Box>
          </Col>
        </Row>
      </Container>
    </Box>
  );
};

export default HomePage;
