import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { Box, CircularProgress } from '@mui/material';
import 'bootstrap/dist/css/bootstrap.min.css';
import { AppProvider, useApp } from './context/AppContext'; // Import useApp
import Sidebar from './components/common/Navbar';
//import TopHeader from './components/common/TopHeader'; // Import TopHeader
import UserDashboard from './components/dashboard/UserDashboard';
import MyTasks from './components/tasks/MyTasks';
import TaskCalendar from './components/calendar/TaskCalendar';
import Analytics from './components/analytics/Analytics';
import HomePage from './pages/HomePage'; // Import HomePage
import Login from './components/auth/Login'; // Import Login
import Signup from './components/auth/Signup'; // Import Signup
import ProtectedRoute from './components/common/ProtectedRoute'; // Import ProtectedRoute
import './App.css';

const theme = createTheme({
  palette: {
    primary: {
      main: '#2678E1',
      dark: '#114A92',
      light: '#ECF4F8',
    },
    secondary: {
      main: '#114A92',
    },
    background: {
      default: '#ECF4F8',
      paper: '#FFFFFF',
    },
    success: {
      main: '#4CAF50',
    },
    warning: {
      main: '#FF9800',
    },
    error: {
      main: '#F44336',
    },
  },
  typography: {
    fontFamily: ['Fredoka', 'Arial', 'sans-serif'].join(','),
    h1: {
      fontFamily: ['Lilita One', 'cursive'].join(','),
    },
    h2: {
      fontFamily: ['Lilita One', 'cursive'].join(','),
    },
    h3: {
      fontFamily: ['Lilita One', 'cursive'].join(','),
    },
    h4: {
      fontFamily: ['League Spartan', 'sans-serif'].join(','),
    },
    h5: {
      fontFamily: ['League Spartan', 'sans-serif'].join(','),
    },
    h6: {
      fontFamily: ['League Spartan', 'sans-serif'].join(','),
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 25,
          textTransform: 'none',
          fontWeight: 600,
          padding: '8px 24px',
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          boxShadow: '0 4px 20px rgba(17, 74, 146, 0.15)',
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 16,
        },
      },
    },
    MuiTextField: { // Add styles for TextField
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            borderRadius: '12px',
          },
        },
      },
    },
    MuiSelect: { // Add styles for Select
      styleOverrides: {
        root: {
          borderRadius: '12px',
        },
      },
    },
  },
});

// Main App component wrapper to provide context
function AppWrapper() {
  const { isAuthenticated, loadingAuth, user, logout } = useApp(); // Get auth state from context

  // Display loading spinner while checking authentication
  if (loadingAuth) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
        <CircularProgress size={60} />
      </Box>
    );
  }

  return (
    <Box className="App" sx={{ display: 'flex' }}>
      {/* Sidebar Navigation - only show if authenticated */}
      {isAuthenticated && <Sidebar user={user} onLogout={logout} />}

      {/* Main Content Area */}
      <Box className="main-content" sx={{ 
        marginLeft: isAuthenticated ? '280px' : 0, // Adjusts for sidebar width
        width: isAuthenticated ? 'calc(100% - 280px)' : '100%', // Takes remaining width
        minHeight: '100vh',
        overflowX: 'hidden' // Prevents horizontal scroll from overflowing content
      }}>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />

          {/* Protected Routes */}
          <Route path="/dashboard" element={<ProtectedRoute><UserDashboard /></ProtectedRoute>} />
          <Route path="/tasks" element={<ProtectedRoute><MyTasks /></ProtectedRoute>} />
          <Route path="/calendar" element={<ProtectedRoute><TaskCalendar /></ProtectedRoute>} />
          <Route path="/analytics" element={<ProtectedRoute><Analytics /></ProtectedRoute>} />
          
          {/* Redirect authenticated users from login/signup to dashboard */}
          {isAuthenticated && (
            <>
              <Route path="/login" element={<Navigate to="/dashboard" replace />} />
              <Route path="/signup" element={<Navigate to="/dashboard" replace />} />
            </>
          )}

          {/* Fallback for unknown routes */}
          <Route path="*" element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />} />
        </Routes>
      </Box>
    </Box>
  );
}

// Root App component to provide ThemeProvider and AppProvider
function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <AppProvider>
          <AppWrapper />
        </AppProvider>
      </Router>
    </ThemeProvider>
  );
}

export default App;
