import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  IconButton, 
  Badge, 
  Avatar, 
  Menu, 
  MenuItem, 
  Divider,
  ListItemIcon,
  ListItemText,
  TextField,
  InputAdornment
} from '@mui/material';
import { 
  Search, 
  Notifications, 
  AccountCircle, 
  Settings, 
  ExitToApp,
  Person,
  NotificationsNone
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import './TopHeader.css';

const TopHeader = ({ pageTitle = "Dashboard", user, onLogout }) => { // Accept user and onLogout props
  const [anchorEl, setAnchorEl] = useState(null);
  const [notificationAnchor, setNotificationAnchor] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate(); // Initialize useNavigate

  const handleProfileClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleNotificationClick = (event) => {
    setNotificationAnchor(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
    setNotificationAnchor(null);
  };

  const handleLogout = () => {
    onLogout();
    navigate('/login');
    handleClose();
  };

  const notifications = [
    {
      id: 1,
      title: "Task Deadline Approaching",
      message: "Complete project proposal by 5 PM today",
      time: "5 min ago",
      unread: true
    },
    {
      id: 2,
      title: "New Team Member Added",
      message: "John Doe joined your team",
      time: "1 hour ago",
      unread: true
    },
    {
      id: 3,
      title: "Weekly Report Ready",
      message: "Your productivity report is available",
      time: "2 hours ago",
      unread: false
    }
  ];

  const unreadCount = notifications.filter(n => n.unread).length;

  return (
    <Box className="top-header">
      <div className="header-left">
        <Typography variant="h4" className="page-title">
          {pageTitle}
        </Typography>
        <Typography variant="body2" className="page-subtitle">
          Welcome back, {user?.name || 'Guest'}! Ready to be productive?
        </Typography>
      </div>

      <div className="header-center">
        <TextField
          className="search-field"
          variant="outlined"
          placeholder="Search Task..."
          size="small"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Search sx={{ color: '#666' }} />
              </InputAdornment>
            ),
          }}
        />
      </div>

      <div className="header-right">
        {/* Notifications */}
        <IconButton 
          className="header-icon-btn"
          onClick={handleNotificationClick}
        >
          <Badge badgeContent={unreadCount} color="error">
            <Notifications />
          </Badge>
        </IconButton>

        {/* User Profile */}
        <div className="user-profile-section">
          <Avatar 
            className="user-avatar-header"
            onClick={handleProfileClick}
            sx={{ cursor: 'pointer' }}
            src={user?.avatarUrl || "https://via.placeholder.com/40"} // Use actual avatar if available
          >
            {user?.name ? user.name.charAt(0).toUpperCase() : 'U'}
          </Avatar>
          {/* Removed redundant IconButton for dropdown, Avatar click handles it */}
        </div>

        {/* Profile Menu */}
        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleClose}
          className="profile-menu"
          transformOrigin={{ horizontal: 'right', vertical: 'top' }}
          anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
        >
          <div className="menu-header">
            <Avatar className="menu-avatar" src={user?.avatarUrl || "https://via.placeholder.com/40"}>
              {user?.name ? user.name.charAt(0).toUpperCase() : 'U'}
            </Avatar>
            <div className="menu-user-info">
              <Typography variant="body1" className="menu-username">
                {user?.name || 'Guest User'}
              </Typography>
              <Typography variant="caption" className="menu-email">
                {user?.email || 'guest@example.com'}
              </Typography>
            </div>
          </div>
          <Divider />
          <MenuItem onClick={handleClose}>
            <ListItemIcon>
              <Person fontSize="small" />
            </ListItemIcon>
            <ListItemText>Profile</ListItemText>
          </MenuItem>
          <MenuItem onClick={handleClose}>
            <ListItemIcon>
              <Settings fontSize="small" />
            </ListItemIcon>
            <ListItemText>Settings</ListItemText>
          </MenuItem>
          <Divider />
          <MenuItem onClick={handleLogout} className="logout-item">
            <ListItemIcon>
              <ExitToApp fontSize="small" />
            </ListItemIcon>
            <ListItemText>Logout</ListItemText>
          </MenuItem>
        </Menu>

        {/* Notifications Menu */}
        <Menu
          anchorEl={notificationAnchor}
          open={Boolean(notificationAnchor)}
          onClose={handleClose}
          className="notifications-menu"
          transformOrigin={{ horizontal: 'right', vertical: 'top' }}
          anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
        >
          <div className="notifications-header">
            <Typography variant="h6">Notifications</Typography>
            <Typography variant="caption" color="primary">
              {unreadCount} new
            </Typography>
          </div>
          <Divider />
          <div className="notifications-list">
            {notifications.map((notification) => (
              <div 
                key={notification.id} 
                className={`notification-item ${notification.unread ? 'unread' : ''}`}
              >
                <div className="notification-icon">
                  <NotificationsNone fontSize="small" />
                </div>
                <div className="notification-content">
                  <Typography variant="body2" className="notification-title">
                    {notification.title}
                  </Typography>
                  <Typography variant="caption" className="notification-message">
                    {notification.message}
                  </Typography>
                  <Typography variant="caption" className="notification-time">
                    {notification.time}
                  </Typography>
                </div>
                {notification.unread && <div className="unread-dot"></div>}
              </div>
            ))}
          </div>
          <Divider />
          <div className="notifications-footer">
            <Typography variant="body2" color="primary" sx={{ cursor: 'pointer' }}>
              View All Notifications
            </Typography>
          </div>
        </Menu>
      </div>
    </Box>
  );
};

export default TopHeader;
